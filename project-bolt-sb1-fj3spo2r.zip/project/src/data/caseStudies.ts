export interface CaseStudy {
  id: string;
  title: string;
  company: string;
  role: string;
  tags: string[];
  heroMetric: { value: string; label: string };
  summary: string;
  context: string;
  problem: string;
  approach: string;
  execution: string[];
  outcome: string;
  reflection: string;
}

export const caseStudies: CaseStudy[] = [
  {
    id: 'ai-faq',
    title: 'Teaching AI to Speak for 100,000 Businesses',
    company: 'NowFloats',
    role: 'Associate Product Manager',
    tags: ['AI/ML', 'Vertical Scaling', 'Data Modeling'],
    heroMetric: { value: '10x', label: 'Verticals covered' },
    summary:
      'Scaling an AI FAQ generator from 1 business vertical to 10 — unlocking contextually relevant Q&As for the entire SME customer base.',
    context:
      "NowFloats' Boost360 and BizHQ platforms help Indian SMEs build their digital presence. One core feature was an AI-powered FAQ generator that automatically created relevant FAQs for business listings — but it only worked for a single business vertical.",
    problem:
      'With 100,000+ SME customers across wildly different industries — from restaurants to law firms to gyms — a one-vertical AI couldn\'t serve 90% of the user base. Businesses outside the original vertical got generic, often irrelevant FAQs that hurt their credibility with customers.',
    approach:
      'Owned the full product strategy to expand from 1 to 10 verticals. This wasn\'t just "add more templates" — it required rethinking the data model, AI generation logic, and how vertical-specific context gets injected into prompts. I wrote the PRD, designed wireframes, defined API specs, and worked directly with engineering on the AI generation pipeline.',
    execution: [
      'Mapped the unique FAQ patterns for each of 10 business verticals through user research and competitive analysis',
      'Designed a flexible data model that could accommodate vertical-specific attributes without ballooning complexity — collaborating with the backend engineer to stress-test schema scalability',
      'Defined the AI prompt engineering approach — each vertical got contextual priming that produced naturally relevant Q&As',
      'Coordinated rollout across both Boost360 and BizHQ platforms simultaneously, syncing with QA and Customer Success for parallel testing',
      'Built QC checkpoints using confidence scoring to catch low-quality generations before they went live',
    ],
    outcome:
      "Expanded AI FAQ coverage from 1 to 10 business verticals — a 10x increase. The generator now serves contextually relevant FAQs to the full breadth of NowFloats' 100,000+ SME customer base across both platforms. Generation quality, measured by confidence scores and manual QC passes, matched or exceeded the original single-vertical performance.",
    reflection:
      'The hardest part wasn\'t the AI — it was the taxonomy. Understanding what makes a "good FAQ" different for a dentist versus a caterer required talking to actual business owners, not just looking at data. This project taught me that scaling AI products is fundamentally a domain-understanding problem, not a technology problem.',
  },
  {
    id: 'reclassification',
    title: 'Reclassifying 100,000 Businesses Nobody Could Find',
    company: 'NowFloats',
    role: 'Associate Product Manager',
    tags: ['Search & Discovery', 'Data Quality', 'Taxonomy'],
    heroMetric: { value: '100K+', label: 'Listings reclassified' },
    summary:
      'A full reclassification initiative across 100,000+ SME listings using a rebuilt 10-vertical taxonomy — sharpening Google Search discoverability for the entire customer base.',
    context:
      'NowFloats maintains digital listings for 100,000+ Indian SMEs. These listings surface on Google Search — which means the business category classification directly impacts whether a potential customer finds them.',
    problem:
      'Years of organic growth had left the classification system broken. Businesses were tagged under wrong or outdated categories. A boutique hotel classified as "Travel Agency." A physiotherapist under "General Physician." Each misclassification was an invisible SEO penalty — the business was online but unfindable.',
    approach:
      'Led a full reclassification initiative across all 100,000+ listings using a rebuilt business taxonomy spanning 10 verticals. Designed a rule-based keyword scoring system combined with confidence-scored QC to automate the bulk of reclassification while flagging edge cases for manual review.',
    execution: [
      'Audited the existing taxonomy and identified the most common misclassification patterns',
      'Built a new 10-vertical taxonomy with clear classification rules and boundary cases documented',
      'Designed the keyword scoring algorithm — each business listing was scored against vertical-specific keyword sets, with confidence thresholds determining auto-classification vs. manual review',
      'Implemented a confidence-scored QC pipeline to validate results before they went live — working with the data team to define threshold calibration',
      'Coordinated with Customer Success to handle edge cases and communicate changes to affected businesses',
    ],
    outcome:
      'Successfully reclassified 100,000+ SME listings across 10 verticals. The improved taxonomy directly sharpened Google Search discoverability for NowFloats\' entire customer base — businesses that were previously invisible for relevant search queries started appearing in the right results.',
    reflection:
      'This project was a masterclass in "infrastructure as product." Nobody sees a taxonomy. No customer asked for reclassification. But the downstream impact on discoverability was enormous. It reinforced my belief that the most impactful PM work is often the work nobody notices.',
  },
  {
    id: 'conversions',
    title: '14% More Conversions, One Test at a Time',
    company: 'Times Internet',
    role: 'Product Executive',
    tags: ['Growth', 'A/B Testing', 'Funnel Optimization'],
    heroMetric: { value: '14%', label: 'Conversion lift' },
    summary:
      'Designed and executed 5+ hypothesis-driven A/B tests across TimesHealth+ and ET Digital — lifting conversion 14% and establishing a test-before-you-ship culture.',
    context:
      'TimesHealth+ and ET Digital are digital properties under Times Internet, one of India\'s largest media conglomerates. I owned the quarterly growth charters — activation, engagement, and conversion KPIs — for both products.',
    problem:
      'Conversion funnels had been designed once and left untouched. Landing pages, CTAs, onboarding flows, and communication touchpoints were all based on assumptions, not data. Nobody was systematically testing what actually worked.',
    approach:
      'Designed and executed 5+ structured A/B tests across the entire conversion funnel — from landing pages to CTAs to onboarding flows to email communication touchpoints. Each test was hypothesis-driven with clear success metrics defined before launch.',
    execution: [
      'Mapped the full user journey from first touch to conversion for both TimesHealth+ and ET Digital',
      'Identified the highest-drop-off points through funnel analysis',
      'Prioritized tests by estimated impact × effort, focusing on the leakiest parts of the funnel first',
      'Ran disciplined A/B tests with proper statistical significance thresholds — no premature winners — partnering with the analytics team to validate sample sizes',
      'Automated funnel, cohort, and user-journey dashboards that saved 10+ hours per week of manual reporting across teams',
      'Turned friction insights into prioritized roadmap bets, sizing each opportunity by potential impact',
    ],
    outcome:
      'Lifted conversion by 14% through systematic experimentation. Automated reporting infrastructure saved 10+ hours per week of manual work across teams. More importantly, established a culture of "test before you ship" in two product teams that previously relied on intuition.',
    reflection:
      "The 14% number is nice, but what I'm prouder of is the reporting automation. The dashboards I built outlasted my tenure — they're still being used. Building systems that keep generating value after you leave is the best kind of product work.",
  },
  {
    id: 'onboarding',
    title: 'Onboarding That Gets SMEs Live in Minutes, Not Days',
    company: 'NowFloats',
    role: 'Associate Product Manager',
    tags: ['0→1 Product', 'AI-Assisted UX', 'Onboarding'],
    heroMetric: { value: '4', label: 'Apps benchmarked (Zomato, Swiggy, Blinkit, Zepto)' },
    summary:
      'Rebuilt the SME onboarding journey from scratch with AI-assisted autofill and smart keyword recommendations — from signup to search-ready profile in minutes.',
    context:
      'NowFloats onboards thousands of SMEs onto its platform every month. The onboarding flow is the first product experience these business owners have — it determines whether they complete their profile setup and go live, or abandon the platform before getting any value.',
    problem:
      'The existing onboarding was a long, manual form that required SMEs to type out their business details from scratch — name, address, services, keywords, descriptions. Most small business owners don\'t think in "SEO keywords" or "business descriptions." Drop-off during onboarding was high, and businesses that did complete it often launched with thin, low-quality profiles that underperformed on search.',
    approach:
      'Revamped the entire onboarding journey from scratch — designing an AI-assisted flow with Google Business Profile autofill and smart keyword recommendations. Benchmarked the new flow against the onboarding UX of Zomato, Swiggy, Blinkit, and Zepto to match consumer-app levels of simplicity for a B2B product.',
    execution: [
      'Audited the existing onboarding funnel step-by-step, identifying every friction point and drop-off trigger',
      'Studied onboarding flows of Zomato, Swiggy, Blinkit, and Zepto — extracted patterns around progressive disclosure, autofill, and minimal-input design',
      'Designed the AI-assisted flow: business owners enter their Google Business Profile link or phone number, and the system autofills name, address, category, hours, and photos — reducing manual input by ~70%',
      'Built smart keyword recommendations that suggest search-ready keywords based on business vertical and location — so even non-tech-savvy owners launch with optimized profiles',
      'Worked closely with the frontend engineer on interaction design and with the ML team on the recommendation engine',
      'Defined success metrics: onboarding completion rate, time-to-live, and Day-7 profile completeness score',
    ],
    outcome:
      'Shipped a reimagined onboarding that gets SMEs from signup to a search-ready live profile in minutes instead of days. The AI-assisted autofill dramatically reduced manual input, and smart keyword recommendations ensured that profiles launched with SEO-optimized content from day one — without the business owner needing to understand SEO.',
    reflection:
      "This was my first true 0→1 product experience — not optimizing something that existed, but reimagining it entirely. The biggest lesson: the best onboarding doesn't teach users your product; it removes the need to learn it. When a restaurant owner taps one button and sees their Google listing auto-populate into a professional profile, that's not a feature — that's trust earned in 10 seconds.",
  },
];
