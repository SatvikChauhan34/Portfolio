import { lazy, Suspense } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import ThemeToggle from '@/components/ThemeToggle';
import { ThemeProvider } from '@/lib/theme';

const CredibilityStrip = lazy(() => import('@/components/CredibilityStrip'));
const ImpactTicker = lazy(() => import('@/components/ImpactTicker'));
const Work = lazy(() => import('@/components/Work'));
const Arsenal = lazy(() => import('@/components/Arsenal'));
const Philosophy = lazy(() => import('@/components/Philosophy'));
const Beyond = lazy(() => import('@/components/Beyond'));
const Connect = lazy(() => import('@/components/Connect'));

function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-bg-primary text-text-primary">
        <ThemeToggle />
        <Navbar />
        <main>
          <Hero />
          <Suspense fallback={null}>
            <CredibilityStrip />
            <ImpactTicker />
            <Work />
            <Philosophy />
            <Arsenal />
            <Beyond />
            <Connect />
          </Suspense>
        </main>
      </div>
    </ThemeProvider>
  );
}

export default App;
