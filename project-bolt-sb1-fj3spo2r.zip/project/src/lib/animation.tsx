import { useEffect, useRef, useState } from 'react';
import { motion, animate, useInView, useSpring } from 'framer-motion';

export const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

export const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: EASE, delay },
  }),
};

interface MagneticProps {
  children: React.ReactNode;
  strength?: number;
  className?: string;
}

export function Magnetic({ children, strength = 0.3, className }: MagneticProps) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useSpring(0, { stiffness: 200, damping: 20 });
  const y = useSpring(0, { stiffness: 200, damping: 20 });

  const handleMouseMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const dx = e.clientX - (rect.left + rect.width / 2);
    const dy = e.clientY - (rect.top + rect.height / 2);
    x.set(dx * strength);
    y.set(dy * strength);
  };

  const reset = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <div
      ref={ref}
      className={className}
      style={{ display: 'inline-block' }}
      onMouseMove={handleMouseMove}
      onMouseLeave={reset}
    >
      <motion.div style={{ x, y }}>{children}</motion.div>
    </div>
  );
}

interface CountUpProps {
  to: number;
  format?: (value: number) => string;
  suffix?: string;
  className?: string;
}

export function CountUp({ to, format, suffix, className }: CountUpProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.2 });
  const [display, setDisplay] = useState('0');

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, to, {
      duration: 1.5,
      ease: 'easeOut',
      onUpdate: (v) => {
        const formatted = Math.round(v).toLocaleString('en-US');
        setDisplay(format ? format(v) : formatted);
      },
      onComplete: () => {
        if (suffix) setDisplay((prev) => prev + suffix);
      },
    });
    return () => controls.stop();
  }, [inView, to, format, suffix]);

  return (
    <span ref={ref} className={className}>
      {display}
    </span>
  );
}
