import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

type EventType = 'email_click' | 'resume_download' | 'company_logo_click';

export function trackEvent(eventType: EventType, detail?: string) {
  supabase
    .from('interaction_events')
    .insert({
      event_type: eventType,
      detail: detail ?? null,
      referrer: document.referrer || null,
      user_agent: navigator.userAgent,
    })
    .then(({ error }) => {
      if (error) console.error('Failed to track event:', error.message);
    });
}
