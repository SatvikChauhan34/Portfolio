import { motion } from 'framer-motion';
import { fadeUp } from '@/lib/animation';

const gradientStyle = {
  backgroundImage: 'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
};

const events = [
  {
    label: 'LEADERSHIP',
    title: 'Founded The South Asian Policy Initiative',
    description:
      "Built and led a 150+ member organization from scratch — producing research on Sustainable Urban Transport, Climate Resilience, and Women's Political Participation across South Asia. Collaborated with students from IITs, JNU, and other premier institutions.",
    date: '2023 – 2024',
  },
  {
    label: 'SOCIAL IMPACT',
    title: 'The Soft Movement — PaperBag Project',
    description:
      'Managed operations for 1,000+ volunteers across 50+ chapters in Indian cities. Secured 6+ institutional partnerships, expanding into 5 new cities.',
    date: '2024',
  },
  {
    label: 'THOUGHT LEADERSHIP',
    title: 'AI in Policy — Talks & Podcasts',
    description:
      "Spoke at St. Stephen's College on AI governance. Podcast guest at Miranda House and the Indian Foreign Policy Project's inaugural Fireside Chat on AI's role in foreign policy.",
    date: '2023 – 2024',
  },
];

export default function Beyond() {
  return (
    <section id="beyond" className="py-16 md:py-20">
      <div className="max-w-content mx-auto px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="text-center"
        >
          <motion.h2
            variants={fadeUp}
            className="font-heading font-semibold text-[36px] md:text-[48px] leading-[54px] tracking-[-0.02em] text-text-primary"
          >
            Beyond Product
          </motion.h2>
          <motion.div
            variants={fadeUp}
            custom={0.1}
            className="w-[60px] h-[3px] mx-auto mt-4"
            style={gradientStyle}
          />
          <motion.p variants={fadeUp} custom={0.2} className="text-text-secondary mt-5">
            Building things bigger than backlogs.
          </motion.p>
        </motion.div>

        <div className="relative mt-10 max-w-3xl mx-auto">
          <div className="absolute left-[7px] md:left-[11px] top-2 bottom-2 w-[2px] bg-border-subtle" />

          <div className="space-y-6">
            {events.map((event, i) => (
              <motion.div
                key={event.title}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.2 }}
                variants={fadeUp}
                custom={i * 0.1}
                className="relative pl-10 md:pl-14"
              >
                <span
                  className="absolute left-0 top-3 w-4 h-4 md:w-6 md:h-6 rounded-full border-4 border-bg-primary"
                  style={{
                    backgroundImage:
                      'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
                  }}
                />
                <div className="bg-bg-secondary rounded-2xl border border-border-subtle p-6 transition-all duration-300 hover:-translate-y-0.5 hover:border-border-hover hover:shadow-glow-indigo will-change-transform">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <p className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-accent-indigo">
                      {event.label}
                    </p>
                    <span className="font-mono font-bold text-sm text-text-tertiary shrink-0">
                      {event.date}
                    </span>
                  </div>
                  <h3 className="font-heading font-semibold text-lg text-text-primary mt-2">
                    {event.title}
                  </h3>
                  <p className="text-base leading-[26px] text-text-secondary mt-2">
                    {event.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
