import { motion } from 'framer-motion';
import { CountUp, fadeUp } from '@/lib/animation';

const metrics = [
  {
    value: 100000,
    suffix: '+',
    label: 'SME customers impacted',
    colorVar: '--accent-mint',
  },
  {
    value: 6,
    suffix: '',
    label: 'Cross-functional teams led',
    colorVar: '--accent-indigo',
  },
  {
    value: 14,
    suffix: '%',
    label: 'Conversion lift via A/B tests',
    colorVar: '--accent-mint',
  },
  {
    value: 10,
    suffix: '+',
    label: 'Products and features shipped',
    colorVar: '--accent-indigo',
  },
];

export default function ImpactTicker() {
  return (
    <section id="impact" className="relative bg-bg-secondary py-16 overflow-hidden">
      <div
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(var(--grid-line) 1px, transparent 1px), linear-gradient(90deg, var(--grid-line) 1px, transparent 1px)`,
          backgroundSize: '48px 48px',
          maskImage: 'linear-gradient(to bottom, transparent, black 30%, black 70%, transparent)',
          WebkitMaskImage:
            'linear-gradient(to bottom, transparent, black 30%, black 70%, transparent)',
        }}
      />
      <div className="relative max-w-content mx-auto px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {metrics.map((metric, i) => {
            const color = `var(${metric.colorVar})`;
            return (
              <motion.div
                key={metric.label}
                variants={fadeUp}
                custom={i * 0.1}
                whileHover={{ y: -6 }}
                transition={{ duration: 0.3 }}
                className="relative pt-6 px-6 py-4 rounded-2xl bg-bg-tertiary/40 overflow-hidden group"
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[2px]"
                  style={{ backgroundColor: color }}
                />
                <div
                  className="absolute -top-10 -right-10 w-32 h-32 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{
                    background: `radial-gradient(circle, color-mix(in srgb, ${color} 15%, transparent) 0%, transparent 70%)`,
                  }}
                />
                <div
                  className="font-mono font-bold text-[36px] md:text-[44px] lg:text-[48px] leading-tight group-hover:scale-[1.03] transition-transform duration-300 origin-left"
                  style={{
                    color,
                    willChange: 'transform',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  <CountUp to={metric.value} suffix={metric.suffix} />
                </div>
                <p className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-text-secondary mt-3">
                  {metric.label}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
