import { motion } from 'framer-motion';
import { ArrowDown, ChevronDown, Download } from 'lucide-react';
import { EASE, Magnetic } from '@/lib/animation';
import { trackEvent } from '@/lib/tracking';
import NameHoverCard from '@/components/NameHoverCard';

const gradientStyle = {
  backgroundImage: 'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
};

export default function Hero() {
  const scrollToWork = () => {
    document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Ambient background layers */}
      <div
        className="absolute pointer-events-none"
        style={{
          width: 600,
          height: 600,
          top: '38%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          background: 'radial-gradient(circle, var(--glow-indigo-soft) 0%, transparent 70%)',
        }}
      />
      <div
        className="absolute inset-0 opacity-40 pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(var(--grid-line) 1px, transparent 1px), linear-gradient(90deg, var(--grid-line) 1px, transparent 1px)`,
          backgroundSize: '64px 64px',
          maskImage: 'radial-gradient(ellipse 80% 60% at 50% 40%, black 30%, transparent 75%)',
          WebkitMaskImage:
            'radial-gradient(ellipse 80% 60% at 50% 40%, black 30%, transparent 75%)',
        }}
      />
      {/* Floating orbs */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 300,
          height: 300,
          top: '15%',
          left: '8%',
          background: 'radial-gradient(circle, color-mix(in srgb, var(--accent-mint) 8%, transparent) 0%, transparent 70%)',
        }}
        animate={{ y: [0, 30, 0], x: [0, 20, 0] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 400,
          height: 400,
          bottom: '10%',
          right: '5%',
          background: 'radial-gradient(circle, var(--glow-indigo-soft) 0%, transparent 70%)',
        }}
        animate={{ y: [0, -25, 0], x: [0, -15, 0] }}
        transition={{ duration: 14, repeat: Infinity, ease: 'easeInOut' }}
      />

      <div className="relative max-w-content mx-auto px-6 text-center pt-16 pb-28">
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: EASE, delay: 0.15 }}
          className="font-heading font-semibold text-lg md:text-xl text-text-secondary tracking-wide mt-0 mb-4"
        >
          Hi, I'm{' '}
          <NameHoverCard
            position="bottom"
            nameClassName="font-semibold text-text-primary text-lg md:text-xl tracking-wide"
          />
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, ease: EASE, delay: 0.3 }}
          className="inline-flex items-center gap-1 px-4 py-1.5 rounded-full border border-border-subtle bg-bg-secondary/60 text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-text-secondary"
        >
          PRODUCT MANAGER · AI-FIRST BUILDER · SYSTEMS THINKER
          <span className="inline-block w-[2px] h-[14px] ml-1 bg-accent-indigo animate-pulse" />
        </motion.p>

        <h1 className="font-heading font-bold text-[36px] md:text-[56px] lg:text-[72px] leading-[1.06] tracking-[-0.03em] mt-6">
          <span className="block overflow-hidden pb-1">
            {'I don\u2019t just ship features.'.split(' ').map((word, i, arr) => (
              <motion.span
                key={i}
                className="inline-block"
                initial={{ opacity: 0, y: '100%' }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.7,
                  ease: EASE,
                  delay: 0.4 + i * 0.08,
                }}
              >
                {word}
                {i < arr.length - 1 ? '\u00A0' : ''}
              </motion.span>
            ))}
          </span>
          <span className="block overflow-hidden pb-1">
            {'I ship '.split(' ').map((word, i) => (
              <motion.span
                key={i}
                className="inline-block"
                initial={{ opacity: 0, y: '100%' }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.7,
                  ease: EASE,
                  delay: 0.9 + i * 0.08,
                }}
              >
                {word}
                {i < 'I ship '.split(' ').length - 1 ? '\u00A0' : ''}
              </motion.span>
            ))}
            <motion.span
              className="inline-block gradient-text"
              style={{
                backgroundSize: '200% 200%',
                animation: 'gradientShift 8s ease-in-out infinite',
              }}
              initial={{ opacity: 0, y: '100%' }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: EASE, delay: 1.06 }}
            >
              outcomes
            </motion.span>
            <motion.span
              className="inline-block"
              initial={{ opacity: 0, y: '100%' }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: EASE, delay: 1.14 }}
            >
              .
            </motion.span>
          </span>
        </h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, ease: EASE, delay: 1.2 }}
          className="text-lg leading-7 text-text-secondary max-w-[600px] mx-auto mt-8"
        >
          I build AI products that scale — currently at NowFloats, where 100,000+ small businesses
          run on what my team ships.
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, ease: EASE, delay: 1.4 }}
          className="flex items-center justify-center gap-2 text-sm font-medium text-text-tertiary mt-5"
        >
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full rounded-full bg-accent-mint opacity-75 animate-ping" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-accent-mint" />
          </span>
          Currently: Scaling AI content tools and rebuilding SME onboarding for Boost360 &amp; BizHQ
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, ease: EASE, delay: 1.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10"
        >
          <Magnetic>
            <motion.button
              onClick={scrollToWork}
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
              transition={{ duration: 0.3, ease: EASE }}
              className="flex items-center gap-2 px-7 py-3 rounded-full text-white font-medium hover:shadow-glow-indigo"
              style={gradientStyle}
            >
              View My Work
              <ArrowDown size={16} />
            </motion.button>
          </Magnetic>
          <Magnetic>
            <motion.a
              href="https://drive.google.com/file/d/1-lB20iKHMExvs5DptF1ZEDG_hxrkaGk5/view?usp=sharing"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackEvent('resume_download', 'hero')}
              whileHover={{ scale: 1.04, borderColor: 'var(--border-hover)' }}
              whileTap={{ scale: 0.97 }}
              transition={{ duration: 0.3, ease: EASE }}
              className="flex items-center gap-2 px-7 py-3 rounded-full border border-border-subtle text-text-secondary hover:text-text-primary"
            >
              Download Resume
              <Download size={16} />
            </motion.a>
          </Magnetic>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, ease: EASE, delay: 2.0 }}
        className="absolute bottom-8 left-0 right-0 flex flex-col items-center gap-1"
      >
        <span className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-text-tertiary">
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronDown size={20} className="text-text-tertiary" />
        </motion.div>
      </motion.div>
    </section>
  );
}
