import { useState } from 'react';
import { motion, useScroll, useSpring, useMotionValueEvent } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { EASE } from '@/lib/animation';
import { trackEvent } from '@/lib/tracking';
import NameHoverCard from '@/components/NameHoverCard';

const gradientStyle = {
  backgroundImage: 'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
};

const navLinks = [
  { label: 'Work', id: 'work' },
  { label: 'Impact', id: 'impact' },
  { label: 'Philosophy', id: 'philosophy' },
  { label: 'Beyond', id: 'beyond' },
  { label: 'Connect', id: 'connect' },
];

const sectionIds = ['hero', 'work', 'impact', 'philosophy', 'beyond', 'connect'];

export default function Navbar() {
  const { scrollYProgress, scrollY } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });
  const [activeSection, setActiveSection] = useState('hero');
  const [menuOpen, setMenuOpen] = useState(false);

  useMotionValueEvent(scrollY, 'change', (latest) => {
    const pos = latest + window.innerHeight * 0.35;
    let current = sectionIds[0];
    for (const id of sectionIds) {
      const el = document.getElementById(id);
      if (el && el.offsetTop <= pos) current = id;
    }
    setActiveSection(current);
  });

  const scrollTo = (id: string) => {
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <motion.header
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="fixed top-0 left-0 right-0 z-50"
        style={{
          background: 'var(--header-bg)',
          backdropFilter: 'blur(24px)',
          WebkitBackdropFilter: 'blur(24px)',
          borderBottom: '1px solid var(--border-subtle)',
        }}
      >
        <motion.div
          className="absolute top-0 left-0 right-0 h-[3px] origin-left"
          style={{
            scaleX: progress,
            ...gradientStyle,
          }}
        />
        <nav className="max-w-content mx-auto flex items-center justify-between px-6 h-16">
          <NameHoverCard
            position="bottom"
            onClick={() => scrollTo('hero')}
            nameClassName="font-heading font-semibold text-text-primary text-base tracking-tight"
          />
          <span style={{ color: 'var(--accent-indigo)' }}>.</span>
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => scrollTo(link.id)}
                  className={`relative text-sm transition-colors duration-300 ${
                    isActive ? 'text-text-primary' : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  {link.label}
                  <span
                    className={`absolute -bottom-1.5 left-0 h-[2px] w-full origin-left transition-transform duration-300 ${
                      isActive ? 'scale-x-100' : 'scale-x-0'
                    }`}
                    style={gradientStyle}
                  />
                </button>
              );
            })}
            <button
              onClick={() => {
                trackEvent('email_click', 'navbar_lets_talk');
                scrollTo('connect');
              }}
              className="px-4 py-2 rounded-full text-sm text-white font-medium transition-all duration-300 hover:shadow-glow-indigo hover:scale-105"
              style={gradientStyle}
            >
              Let's Talk
            </button>
          </div>

          <button
            className="md:hidden text-text-secondary"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>
      </motion.header>

      {menuOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3, ease: EASE }}
          className="fixed inset-0 z-40 md:hidden flex flex-col items-center justify-center gap-8"
          style={{
            background: 'var(--overlay-bg)',
            backdropFilter: 'blur(24px)',
            WebkitBackdropFilter: 'blur(24px)',
          }}
        >
          {navLinks.map((link, i) => (
            <motion.button
              key={link.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: EASE, delay: 0.05 * i }}
              onClick={() => scrollTo(link.id)}
              className="font-heading font-semibold text-3xl text-text-primary"
            >
              {link.label}
            </motion.button>
          ))}
        </motion.div>
      )}
    </>
  );
}
