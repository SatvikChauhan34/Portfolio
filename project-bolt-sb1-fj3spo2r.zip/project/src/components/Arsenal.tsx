import { motion } from 'framer-motion';
import {
  BarChart3,
  Brain,
  Bug,
  FileText,
  FlaskConical,
  IterationCw,
  Map,
  Presentation,
  Scale,
  Search,
  Target,
  type LucideIcon,
} from 'lucide-react';
import { fadeUp } from '@/lib/animation';

const gradientStyle = {
  backgroundImage: 'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
};

interface Tool {
  name: string;
  logo?: string;
  monogram?: string;
  color?: string;
}

const tools: Tool[] = [
  { name: 'Claude Code', logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQIeNTucM3P0SQ0QZrWew3doyjegcCBk1jsmk9gJxsC6ZGoJwuRvweJuqE&s=10' },
  { name: 'Cursor', logo: 'https://cdn.simpleicons.org/cursor/FFFFFF' },
  { name: 'Bolt', logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyeaFYPkZ_38cQIEI9tW57r_DYvT6jJ_1aRZIeVEs1idWrXXZmOOS-qktJ&s=10' },
  { name: 'Replit', logo: 'https://cdn.simpleicons.org/replit/F26207' },
  { name: 'Nano Bana', monogram: 'N', color: '#00D4AA' },
  { name: 'n8n', logo: 'https://cdn.simpleicons.org/n8n/EA4B71' },
  { name: 'Zapier', logo: 'https://images.seeklogo.com/logo-png/27/1/zapier-logo-png_seeklogo-274108.png' },
  { name: 'Python', logo: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/1280px-Python-logo-notext.svg.png' },
  { name: 'SQL', monogram: '{}', color: '#6C63FF' },
  { name: 'MongoDB', logo: 'https://cdn.simpleicons.org/mongodb/47A248' },
  { name: 'Power BI', logo: 'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/cf/New_Power_BI_Logo.svg/1280px-New_Power_BI_Logo.svg.png' },
  { name: 'Figma', logo: 'https://cdn.simpleicons.org/figma/F24E1E' },
  { name: 'Google AI Studio', logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7jA9TVTh8IpYQuPjb7KmtwUg0Xffyx507eKJ1F_9ZVg&s=10' },
];

interface Skill {
  name: string;
  icon: LucideIcon;
}

const skills: Skill[] = [
  { name: 'Product Management', icon: Target },
  { name: 'A/B Testing', icon: FlaskConical },
  { name: 'Stakeholder Reporting', icon: Presentation },
  { name: 'Feature Usage Analytics', icon: BarChart3 },
  { name: 'PRDs & Specs', icon: FileText },
  { name: 'Roadmapping', icon: Map },
  { name: 'Build-vs-Partner Eval', icon: Scale },
  { name: 'Vendor Assessment', icon: Search },
  { name: 'AI Product Scoping', icon: Brain },
  { name: 'Bug Triage', icon: Bug },
  { name: 'Agile/Scrum', icon: IterationCw },
];

function ToolCard({ tool }: { tool: Tool }) {
  return (
    <div className="tool-card w-[60px] h-[60px] shrink-0">
      <div className="tool-card-inner relative w-full h-full">
        <div className="tool-card-front absolute inset-0 flex items-center justify-center rounded-xl bg-[#12121A] border border-[#1F1F35]">
          {tool.logo ? (
            <img src={tool.logo} alt={tool.name} className="w-7 h-7" loading="lazy" />
          ) : (
            <span className="text-lg font-bold font-mono" style={{ color: tool.color }}>
              {tool.monogram}
            </span>
          )}
        </div>
        <div
          className="tool-card-back absolute inset-0 flex items-center justify-center rounded-xl text-center p-1"
          style={{ background: 'rgba(108,99,255,0.08)', border: '1px solid rgba(108,99,255,0.25)' }}
        >
          <span className="text-[10px] font-semibold text-white leading-tight">{tool.name}</span>
        </div>
      </div>
    </div>
  );
}

export default function Arsenal() {
  return (
    <section id="arsenal" className="py-16 md:py-20">
      <div className="max-w-content mx-auto px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="text-center"
        >
          <motion.h2
            variants={fadeUp}
            className="font-heading font-semibold text-[36px] md:text-[48px] leading-[54px] tracking-[-0.02em] text-text-primary"
          >
            My Arsenal
          </motion.h2>
          <motion.div
            variants={fadeUp}
            custom={0.1}
            className="w-[60px] h-[3px] mx-auto mt-4"
            style={gradientStyle}
          />
          <motion.p variants={fadeUp} custom={0.2} className="text-text-secondary text-base mt-5">
            Tools I ship with, skills I think in.
          </motion.p>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeUp}
          className="mt-10 space-y-6"
        >
          <div className="overflow-hidden marquee-mask py-1">
            <div className="flex w-max items-center gap-4 pr-4 marquee-tools">
              {[...tools, ...tools].map((tool, i) => (
                <ToolCard key={`${tool.name}-${i}`} tool={tool} />
              ))}
            </div>
          </div>

          <div className="overflow-hidden marquee-mask py-1">
            <div className="flex w-max items-center gap-3 pr-3 marquee-skills">
              {[...skills, ...skills].map((skill, i) => (
                <span
                  key={`${skill.name}-${i}`}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-bg-secondary/60 border border-border-subtle text-text-secondary text-sm whitespace-nowrap transition-colors duration-300 hover:text-text-primary hover:border-accent-indigo/30 cursor-default"
                >
                  <skill.icon size={14} className="text-accent-indigo shrink-0" />
                  {skill.name}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
