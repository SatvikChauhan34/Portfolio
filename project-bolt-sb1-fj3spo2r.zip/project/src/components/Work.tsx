import { useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X } from 'lucide-react';
import { caseStudies, type CaseStudy } from '@/data/caseStudies';
import { EASE, fadeUp } from '@/lib/animation';

const gradientStyle = {
  backgroundImage: 'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
};

function SectionHeader() {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.2 }}
      className="text-center"
    >
      <motion.h2
        variants={fadeUp}
        className="font-heading font-semibold text-[36px] md:text-[48px] leading-[54px] tracking-[-0.02em] text-text-primary"
      >
        The Work
      </motion.h2>
      <motion.div
        variants={fadeUp}
        custom={0.1}
        className="w-[60px] h-[3px] mx-auto mt-4"
        style={gradientStyle}
      />
      <motion.p
        variants={fadeUp}
        custom={0.2}
        className="text-text-secondary text-base leading-[26px] mt-5"
      >
        Every product decision backed by data. Every launch measured by outcomes.
      </motion.p>
    </motion.div>
  );
}

function ExpandedBody({ study }: { study: CaseStudy }) {
  return (
    <div className="relative pl-6 mt-8">
      <div
        className="absolute left-0 top-0 bottom-0 w-[2px]"
        style={gradientStyle}
      />

      {[
        { label: 'THE CONTEXT', body: study.context },
        { label: 'THE PROBLEM', body: study.problem },
        { label: 'THE APPROACH', body: study.approach },
      ].map((block) => (
        <div key={block.label} className="mb-7">
          <p className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-accent-indigo">
            {block.label}
          </p>
          <p className="text-base leading-[26px] text-text-primary mt-2">{block.body}</p>
        </div>
      ))}

      <div className="mb-7">
        <p className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-accent-indigo">
          THE EXECUTION
        </p>
        <ul className="mt-2 space-y-2">
          {study.execution.map((item) => (
            <li key={item} className="flex gap-3 text-base leading-[26px] text-text-primary">
              <span className="text-accent-mint shrink-0">—</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="mb-7">
        <p className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-accent-indigo">
          THE OUTCOME
        </p>
        <p className="text-base leading-[26px] text-text-primary mt-2">{study.outcome}</p>
      </div>

      <div>
        <p className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-accent-indigo">
          REFLECTION
        </p>
        <blockquote className="mt-3 pl-4 border-l-2 border-border-subtle italic text-[15px] leading-[24px] text-text-secondary">
          {study.reflection}
        </blockquote>
      </div>
    </div>
  );
}

export default function Work() {
  const [openId, setOpenId] = useState<string | null>(null);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const toggle = (id: string) => {
    setOpenId((prev) => {
      const next = prev === id ? null : id;
      if (next) {
        requestAnimationFrame(() => {
          setTimeout(() => {
            const el = cardRefs.current[id];
            if (el) {
              const top = el.getBoundingClientRect().top + window.scrollY - 88;
              window.scrollTo({ top, behavior: 'smooth' });
            }
          }, 250);
        });
      }
      return next;
    });
  };

  return (
    <section id="work" className="py-16 md:py-20">
      <div className="max-w-content mx-auto px-6">
        <SectionHeader />

        <div className="mt-10 space-y-5">
          {caseStudies.map((study, i) => {
            const isOpen = openId === study.id;
            return (
              <motion.div
                key={study.id}
                variants={fadeUp}
                custom={i * 0.1}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.2 }}
                layout
                transition={{ layout: { duration: 0.5, ease: EASE } }}
                ref={(el) => {
                  cardRefs.current[study.id] = el;
                }}
                onClick={() => toggle(study.id)}
                className={`card-spotlight relative bg-bg-secondary rounded-2xl border p-6 cursor-pointer transition-all duration-300 hover:-translate-y-0.5 will-change-transform overflow-hidden ${
                  isOpen
                    ? 'border-accent-indigo/40 shadow-glow-indigo'
                    : 'border-border-subtle hover:border-border-hover hover:shadow-glow-indigo'
                }`}
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  e.currentTarget.style.setProperty('--mx', `${e.clientX - rect.left}px`);
                  e.currentTarget.style.setProperty('--my', `${e.clientY - rect.top}px`);
                }}
              >
                <span
                  className="absolute top-0 left-0 h-full w-[2px] opacity-0 hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={gradientStyle}
                />
                <div className="flex flex-col md:flex-row md:items-start gap-6 md:gap-10">
                  <div className="md:w-[60%]">
                    <div className="flex items-start justify-between gap-4">
                      <h3 className="font-heading font-semibold text-2xl leading-[30px] text-text-primary">
                        {study.title}
                      </h3>
                      {isOpen && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggle(study.id);
                          }}
                          className="shrink-0 text-text-secondary hover:text-text-primary transition-colors duration-300"
                          aria-label="Close case study"
                        >
                          <X size={20} />
                        </button>
                      )}
                    </div>
                    <p className="text-[13px] leading-[18px] font-medium uppercase tracking-[0.08em] text-text-tertiary mt-2">
                      {study.company} · {study.role}
                    </p>
                    <p className="text-base leading-[26px] text-text-secondary mt-3">
                      {study.summary}
                    </p>
                    <div className="flex flex-wrap gap-2 mt-4">
                      {study.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-[11px] font-medium tracking-wider uppercase px-3 py-1 rounded-full bg-[#6C63FF10] text-[#9990FF] border border-[#6C63FF25] hover:bg-[#6C63FF20] hover:border-[#6C63FF40] hover:text-[#B0A8FF] transition-all duration-300 cursor-default"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="md:w-[40%] md:text-right flex md:block items-baseline gap-3">
                    <motion.span
                      whileHover={{ scale: 1.06 }}
                      className="inline-block font-mono font-bold text-[40px] md:text-[48px] text-accent-mint"
                    >
                      {study.heroMetric.value}
                    </motion.span>
                    <span className="block text-sm font-medium text-text-secondary mt-1">
                      {study.heroMetric.label}
                    </span>
                    <span className="hidden md:block text-sm text-accent-indigo mt-4">
                      {isOpen ? '' : 'Read Case Study →'}
                    </span>
                  </div>
                </div>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      key="body"
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.5, ease: EASE }}
                      className="overflow-hidden"
                    >
                      <ExpandedBody study={study} />
                    </motion.div>
                  )}
                </AnimatePresence>

                {!isOpen && (
                  <span className="md:hidden block text-sm text-accent-indigo mt-5 text-right">
                    Read Case Study →
                  </span>
                )}
              </motion.div>
            );
          })}
        </div>

        <p className="text-center text-sm text-text-tertiary mt-8">
          More case studies in progress — check back soon.
        </p>
      </div>
    </section>
  );
}
