import { motion } from 'framer-motion';
import { Moon, Sun } from 'lucide-react';
import { useTheme } from '@/lib/theme';
import { EASE } from '@/lib/animation';

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const isLight = theme === 'light';

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, ease: EASE, delay: 1 }}
      className="fixed left-4 top-1/2 -translate-y-1/2 z-50"
    >
      <div
        className="flex flex-col items-center gap-1 p-1.5 rounded-full border border-border-subtle"
        style={{ background: 'var(--header-bg)', backdropFilter: 'blur(16px)' }}
      >
        <button
          onClick={() => setTheme('dark')}
          aria-label="Switch to dark mode"
          className={`relative p-2 rounded-full transition-colors duration-300 ${
            !isLight ? 'text-text-primary' : 'text-text-tertiary hover:text-text-secondary'
          }`}
        >
          {!isLight && (
            <motion.span
              layoutId="theme-pill"
              className="absolute inset-0 rounded-full"
              style={{
                backgroundImage:
                  'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
              }}
              transition={{ duration: 0.4, ease: EASE }}
            />
          )}
          <Moon size={16} className="relative" />
        </button>
        <button
          onClick={() => setTheme('light')}
          aria-label="Switch to light mode"
          className={`relative p-2 rounded-full transition-colors duration-300 ${
            isLight ? 'text-white' : 'text-text-tertiary hover:text-text-secondary'
          }`}
        >
          {isLight && (
            <motion.span
              layoutId="theme-pill"
              className="absolute inset-0 rounded-full"
              style={{
                backgroundImage:
                  'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
              }}
              transition={{ duration: 0.4, ease: EASE }}
            />
          )}
          <Sun size={16} className="relative" />
        </button>
      </div>
    </motion.div>
  );
}
