import { motion } from 'framer-motion';
import { EASE, fadeUp } from '@/lib/animation';
import { trackEvent } from '@/lib/tracking';

interface Company {
  name: string;
  logo: string;
  linkedin: string;
}

const companies: Company[] = [
  {
    name: 'NowFloats',
    logo: 'https://media.licdn.com/dms/image/v2/C4E0BAQEywhdvm5oJiQ/company-logo_200_200/company-logo_200_200/0/1631326921003?e=1793836800&v=beta&t=3fFsLuk5lcEexOf9HS5eusd7vlX-JvdedW5KEIF-zZI',
    linkedin: 'https://www.linkedin.com/company/nowfloats/posts/?feedView=all',
  },
  {
    name: 'Times Internet',
    logo: 'https://media.licdn.com/dms/image/v2/D560BAQHCqKgi01rWpQ/company-logo_200_200/company-logo_200_200/0/1737028817554/timesinternet_logo?e=1793836800&v=beta&t=W_cFJFjP5NBgHUPpesfhK4QB-Z0vBslAf644gSZm-Vo',
    linkedin: 'https://www.linkedin.com/company/timesinternet/posts/',
  },
  {
    name: 'ReachInBox AI',
    logo: 'https://media.licdn.com/dms/image/v2/D4D0BAQErt72ovTbwfw/company-logo_200_200/B4DZ.UFbwrH0AE-/0/1784895880670/reachinbox_ai_logo?e=1793836800&v=beta&t=kaqvVIL2mrc8N5o8KQf8pWpkSJ0xNrp2SaKxAvhHBpY',
    linkedin: 'https://www.linkedin.com/company/reachinbox-ai/posts/?feedView=all',
  },
  {
    name: 'Koo',
    logo: 'https://media.licdn.com/dms/image/v2/C560BAQHUI-y1Eo-uHg/company-logo_200_200/company-logo_200_200/0/1669894099921/koo_india_logo?e=1793836800&v=beta&t=qd78wHf48KT1WRiljgAYgscATv2S9Gt2ES9GGU44H8s',
    linkedin: 'https://www.linkedin.com/company/koo-india/posts/?feedView=all',
  },
];

export default function CredibilityStrip() {
  return (
    <section className="bg-bg-secondary py-10">
      <div className="max-w-content mx-auto px-6">
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: EASE }}
          className="text-center text-[11px] font-medium uppercase tracking-[0.08em] text-text-tertiary"
        >
          TRUSTED BY &amp; WORKED WITH
        </motion.p>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="flex flex-wrap items-center justify-center gap-6 md:gap-12 mt-6"
        >
          {companies.map((company, i) => (
            <motion.a
              key={company.name}
              href={company.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackEvent('company_logo_click', company.name)}
              variants={fadeUp}
              custom={i * 0.1}
              className="group relative flex flex-col items-center gap-2"
              aria-label={`${company.name} on LinkedIn`}
            >
              <motion.div
                whileHover={{ scale: 1.12, rotate: -2 }}
                whileTap={{ scale: 0.95 }}
                transition={{ duration: 0.3, ease: EASE }}
                className="relative w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white p-2 flex items-center justify-center overflow-hidden"
                style={{ boxShadow: '0 0 0 1px var(--border-subtle)' }}
              >
                <img
                  src={company.logo}
                  alt={`${company.name} logo`}
                  className="w-full h-full object-contain rounded-lg"
                  loading="lazy"
                />
                <span
                  className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{
                    boxShadow: '0 0 24px color-mix(in srgb, var(--accent-indigo) 45%, transparent)',
                  }}
                />
              </motion.div>
              <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-text-tertiary group-hover:text-text-secondary transition-colors duration-300">
                {company.name}
              </span>
            </motion.a>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
