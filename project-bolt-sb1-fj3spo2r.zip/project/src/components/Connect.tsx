import { motion } from 'framer-motion';
import { Linkedin, Mail } from 'lucide-react';
import { fadeUp } from '@/lib/animation';
import { trackEvent } from '@/lib/tracking';

const gradientStyle = {
  backgroundImage: 'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)',
};

export default function Connect() {
  return (
    <section id="connect" className="pt-16 md:pt-20 pb-8">
      <div className="max-w-content mx-auto px-6 text-center">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          <motion.h2
            variants={fadeUp}
            className="font-heading font-semibold text-[36px] md:text-[48px] leading-[54px] tracking-[-0.02em] text-text-primary"
          >
            Got a Hard Problem?
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={0.1}
            className="text-lg leading-7 text-text-secondary max-w-[520px] mx-auto mt-5"
          >
            Building something where AI meets scale? If you've got a hard problem worth solving, I'd
            love to hear about it — reach out and let's talk.
          </motion.p>
          <motion.div
            variants={fadeUp}
            custom={0.2}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8"
          >
            <a
              href="mailto:satvikchauhan34@gmail.com"
              onClick={() => trackEvent('email_click', 'connect_section')}
              className="flex items-center gap-2 px-7 py-3 rounded-full text-white font-medium transition-all duration-300 hover:shadow-glow-indigo hover:scale-105"
              style={gradientStyle}
            >
              <Mail size={16} />
              Email Me
            </a>
            <a
              href="https://linkedin.com/in/satvik-chauhan-903aba248"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-7 py-3 rounded-full border border-border-subtle text-text-secondary hover:text-text-primary hover:scale-105 transition-all duration-300"
            >
              <Linkedin size={16} />
              LinkedIn
            </a>
          </motion.div>
        </motion.div>

        <footer className="border-t border-border-subtle mt-12 pt-6 pb-2 flex items-center justify-center text-[13px] text-text-tertiary">
          <span>© 2026 Satvik Chauhan</span>
        </footer>
      </div>
    </section>
  );
}
