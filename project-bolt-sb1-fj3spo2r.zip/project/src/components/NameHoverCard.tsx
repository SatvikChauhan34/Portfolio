import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Linkedin, Mail } from 'lucide-react';
import { trackEvent } from '@/lib/tracking';

interface NameHoverCardProps {
  nameClassName?: string;
  onClick?: () => void;
  position?: 'bottom' | 'top';
}

export default function NameHoverCard({
  nameClassName = '',
  onClick,
  position = 'bottom',
}: NameHoverCardProps) {
  const [show, setShow] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleEnter = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setShow(true);
  };

  const handleLeave = () => {
    timeoutRef.current = setTimeout(() => setShow(false), 150);
  };

  useEffect(
    () => () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    },
    []
  );

  return (
    <span
      className="relative inline-block"
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
    >
      <button
        type="button"
        onClick={onClick}
        className={`bg-transparent border-0 border-b border-dotted border-[#6C63FF40] p-0 cursor-pointer ${nameClassName}`}
      >
        Satvik Chauhan
      </button>
      <AnimatePresence>
        {show && (
          <span
            className={`absolute left-1/2 -translate-x-1/2 z-50 block w-[320px] max-w-[calc(100vw-32px)] ${
              position === 'bottom' ? 'top-full mt-3' : 'bottom-full mb-3'
            }`}
          >
            <motion.span
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              className="block rounded-2xl p-5"
              style={{
                background: 'rgba(18,18,26,0.85)',
                backdropFilter: 'blur(20px)',
                WebkitBackdropFilter: 'blur(20px)',
                border: '1px solid rgba(108,99,255,0.15)',
                boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
              }}
            >
              <img
                src="/images/profile.png"
                alt="Satvik Chauhan"
                className="w-24 h-24 rounded-full object-cover"
                style={{ border: '2px solid rgba(108,99,255,0.3)' }}
              />
              <span className="block text-[16px] font-semibold text-white mt-3">
                Satvik Chauhan
              </span>
              <span className="block text-[13px] text-[#7575A0] mt-0.5">
                Product Manager · AI-First Builder
              </span>
              <span className="block text-[13px] text-[#8888A0] mt-2 leading-relaxed">
                I build systems that scale — from AI agents to growth engines. Currently driving
                product at NowFloats, where I've shipped AI tools for 100,000+ SMEs, expanded AI
                FAQ coverage across 10 business verticals, and rebuilt onboarding end-to-end.
                Previously at Times Internet, lifting conversions 14% through disciplined A/B
                testing. Turning SMB pain points into shipped solutions — one PRD at a time.
              </span>
              <span className="flex gap-3 mt-3">
                <a
                  href="https://linkedin.com/in/satvik-chauhan-903aba248"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackEvent('linkedin_click', 'name_popover')}
                  className="flex items-center gap-1.5 text-[12px] text-[#B0B0C8] border border-[#1F1F35] rounded-full px-3 py-1 transition-all duration-300 hover:text-white hover:border-[#6C63FF50] hover:shadow-[0_0_16px_rgba(108,99,255,0.35)]"
                >
                  <Linkedin size={12} />
                  Connect
                </a>
                <a
                  href="mailto:satvikchauhan34@gmail.com"
                  onClick={() => trackEvent('email_click', 'name_popover')}
                  className="flex items-center gap-1.5 text-[12px] text-[#B0B0C8] border border-[#1F1F35] rounded-full px-3 py-1 transition-all duration-300 hover:text-white hover:border-[#6C63FF50] hover:shadow-[0_0_16px_rgba(108,99,255,0.35)]"
                >
                  <Mail size={12} />
                  Email
                </a>
              </span>
            </motion.span>
          </span>
        )}
      </AnimatePresence>
    </span>
  );
}
