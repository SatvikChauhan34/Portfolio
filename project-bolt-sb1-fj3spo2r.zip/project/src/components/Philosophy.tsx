import { motion } from 'framer-motion';
import { BarChart3, Layers, Search, Zap } from 'lucide-react';
import { fadeUp } from '@/lib/animation';

const principles = [
  {
    icon: Search,
    title: 'Start With the Friction',
    description:
      "I don't start with solutions. I start with the moment a user gets stuck — the drop-off point, the confused click, the support ticket. The best products are built backward from frustration.",
    reference: 'See: 14% More Conversions',
  },
  {
    icon: BarChart3,
    title: 'Measure the Outcome, Not the Output',
    description:
      "Shipped features don't matter. Changed metrics do. Every PRD I write starts with the number we're trying to move and ends with how we'll know we moved it.",
    reference: 'See: 14% More Conversions',
  },
  {
    icon: Layers,
    title: 'Infrastructure Is Product',
    description:
      "Taxonomy reclassification. Reporting automation. Data model redesign. The work nobody sees often creates the most value. I'm not afraid of the invisible wins.",
    reference: 'See: Reclassifying 100K Businesses',
  },
  {
    icon: Zap,
    title: 'Ship, Learn, Iterate',
    description:
      "Perfect specs don't survive contact with real users. I'd rather ship a focused V1 in two weeks and learn from live data than spend two months polishing assumptions. Speed is a feature.",
    reference: 'See: Onboarding That Gets SMEs Live',
  },
];

export default function Philosophy() {
  return (
    <section id="philosophy" className="py-16 md:py-20">
      <div className="max-w-content mx-auto px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="text-center"
        >
          <motion.h2
            variants={fadeUp}
            className="font-heading font-semibold text-[36px] md:text-[48px] leading-[54px] tracking-[-0.02em] text-text-primary"
          >
            How I Build
          </motion.h2>
          <motion.div
            variants={fadeUp}
            custom={0.1}
            className="w-[60px] h-[3px] mx-auto mt-4"
            style={{ backgroundImage: 'linear-gradient(135deg, var(--accent-indigo) 0%, var(--accent-mint) 100%)' }}
          />
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10"
        >
          {principles.map((principle, i) => (
            <motion.div
              key={principle.title}
              variants={fadeUp}
              custom={i * 0.1}
              className="bg-bg-secondary rounded-2xl border border-border-subtle p-6 overflow-hidden relative transition-all duration-300 hover:-translate-y-1 hover:border-border-hover hover:shadow-glow-indigo will-change-transform group"
            >
              <div
                className="absolute -top-16 -right-16 w-48 h-48 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{
                  background:
                    'radial-gradient(circle, var(--glow-indigo-card) 0%, transparent 70%)',
                }}
              />
              <principle.icon size={32} className="text-accent-indigo relative" />
              <h3 className="font-heading font-semibold text-xl text-text-primary mt-5">
                {principle.title}
              </h3>
              <p className="text-base leading-[26px] text-text-secondary mt-3">
                {principle.description}
              </p>
              <p className="text-sm italic text-text-tertiary mt-5">{principle.reference}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
