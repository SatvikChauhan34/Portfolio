/*
# Create interaction_events table for portfolio click tracking

1. New Tables
- `interaction_events`
  - `id` (uuid, primary key, auto-generated)
  - `event_type` (text, not null) — what was clicked: `email_click`, `resume_download`, or `company_logo_click`
  - `detail` (text, nullable) — extra context, e.g. which company logo was clicked
  - `referrer` (text, nullable) — the page the visitor came from
  - `user_agent` (text, nullable) — visitor's browser/device string
  - `created_at` (timestamp, defaults to now)
2. Security
- Enable RLS on `interaction_events`.
- INSERT-only policy for anon + authenticated: visitors can record clicks but nobody can read, change, or delete the data through the public website. Only the site owner reads the data via the Supabase dashboard.
3. Notes
- No sign-in exists on this site, so policies are scoped `TO anon, authenticated`.
- No SELECT/UPDATE/DELETE policies — the table is write-only for the public, keeping captured data private.
*/

CREATE TABLE IF NOT EXISTS interaction_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  detail text,
  referrer text,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE interaction_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_interaction_events" ON interaction_events;
CREATE POLICY "anon_insert_interaction_events" ON interaction_events
FOR INSERT
TO anon, authenticated
WITH CHECK (true);
